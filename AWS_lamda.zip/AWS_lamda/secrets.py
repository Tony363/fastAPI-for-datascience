Key = 'f08508681325cceece6b9edcc05d39e1b4616b6db9dadcd5a9c386e92f54bc9f'

ID = 'PKS6W5GM7B4K3YWIEX4C'

secret = 'hfXPJ9MQmllMjNDojeaU9hldPLLraDlUu7uqXqVG'

algorithm = 'HS256'

api_key = 'PKASJH4T6AUDT80MLN5N'
api_secret = 'NVvgmnqdfANUokW9SzANPJ/hX5dDxFj1NZMDW9cV'
base_url = 'https://paper-api.alpaca.markets'